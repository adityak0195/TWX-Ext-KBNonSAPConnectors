package com.kb.sftp;

import java.util.Vector;
import com.kb.sftp.swsSession;

public class swsTest {

	public static void main(String[] args) {

		java.io.PrintStream out = System.out;

		try {
			swsSession session = new swsSession("TESTPLANT");
			swsSftpChannel swsSftpChannel = new swsSftpChannel(session);

			try {
				Vector<swsLsEntry> files = swsSftpChannel.ls();
				if (files != null) {
					for (int ii = 0; ii < files.size(); ii++) {
						//out.println(files.elementAt(ii).toString());

						swsLsEntry entry = files.elementAt(ii);
						if (!entry.getLongname().startsWith("d")) {
							String filename = entry.getFilename();
							out.println("******************************************");
							out.println("--> "+filename);
							swsSftpChannel.get(filename, "c:/Temp/"+filename);
							out.println("...downloaded");
							swsSftpChannel.rm(filename);
							out.println("...deleted");
							out.println("******************************************");
						}

					}
				}
			} catch (swsException e) {
				out.println("**********");
				out.println(e.toString());
			} finally {
				out.println("closing channel...");
				swsSftpChannel.closeChannel();
				out.println("...done");
				out.println("closing session...");
				session.closeSession();
				out.println("done...");
			}
		} catch (Exception e) {
			out.println(e.toString());
			//e.printStackTrace();
		}
	}

}