package com.kb.sftp;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Logger;
import com.jcraft.jsch.Session;


public class swsSession {

	final static String _host = "sftp.knorr-bremse.com";
	final static String _dir = "/home/sws/";
	final static int _port = 22;
	final static String _user = "sws";
	final static String _passphrase = "Au0kV/4o";
	final static String _privKey = "-----BEGIN EC PRIVATE KEY-----\r\n" + 
			"Proc-Type: 4,ENCRYPTED\r\n" + 
			"DEK-Info: AES-128-CBC,B0768AF7A978E09075E625B601392BBD\r\n" + 
			"\r\n" + 
			"TG45mjlGY6h02ifMRxCXUFIpO1tzHoZy3eix0Yj8kbdquIrw7T8w1tVIbJ9cdeJi\r\n" + 
			"VnBwmhht2z1OpmninHHPJOTy9VZXJ9epCq+CmY0xmEFBrf57ZtEJ86uXmwEnUiC/\r\n" + 
			"3A8IR00MZ65l42XZZhPFjQbIEJGs/m2bewju9L1yVSLi0VdcOr2M/0bZKBowkkTz\r\n" + 
			"0R4Mr14lXiZwZEawdOUw0m0igg9W3n1ysQ6cWIQiyRPsdwY/3bnkg9uYbwhWDO9H\r\n" + 
			"R8dllq23++NYenXnv/Abl1huyfc6txNKBMu57mi7nzk=\r\n" + 
			"-----END EC PRIVATE KEY-----\r\n";
	
	private String plantId;
	private Session session;
	
	public swsSession(String plantId) throws swsException {
		try {
			this.plantId = plantId;
			JSch jsch = new JSch();
			JSch.setLogger(SIMPLE_LOGGER);
			System.out.println("connect...");
			jsch.addIdentity("martin.flassak@knorr-bremse.com",_privKey.getBytes(), null, _passphrase.getBytes());
			session = jsch.getSession(_user, _host, _port);
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			config.put("PreferredAuthentications", "publickey");
			session.setConfig(config);
			session.connect();
			System.out.println("...done");
		} catch (JSchException e) {
			throw new swsException(e);
		}
	}
	
	public Session getSession() {
		return session;
	}
	
	public String getDir() {
		return _dir+plantId+"/";
	}

	public void closeSession() {
		session.disconnect();
	}
	
	private static final Logger SIMPLE_LOGGER = new Logger() {
		public boolean isEnabled(int level) {
			return true;
		}

		public void log(int level, String message) {
			System.out.println(message);
		}
	};
}
