package com.kb.sftp;

@SuppressWarnings("serial")
public class swsException extends Exception{

	public swsException()
	   {
	   }

	   public swsException(String msg)
	   {
	      super(msg);
	   }

	   public swsException(Exception e)
	   {
	      super(e);
	   }
}
