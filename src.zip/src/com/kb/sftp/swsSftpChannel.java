package com.kb.sftp;

import java.util.Vector;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.SftpException;
import com.jcraft.jsch.ChannelSftp.LsEntry;

public class swsSftpChannel {
	
	private Channel channel;
	private ChannelSftp channelSftp;
	private String dir;
	
	public swsSftpChannel(swsSession session) throws swsException {
		try {
			System.out.println("open channel...");
			channel = session.getSession().openChannel("sftp");
			channel.connect();
			dir = session.getDir();
			channelSftp = (ChannelSftp) channel;
			System.out.println("...done");
            try {
            	channelSftp.ls(dir);
            }catch (SftpException e1) {
            	try {
					channelSftp.mkdir(dir);
				} catch (SftpException e) {
					throw new swsException(e);
				}
			}	
		} catch (JSchException e) {
			throw new swsException(e);
		}
	}
	
	public ChannelSftp getChannel() {
		return channelSftp;
	}
	
	public void closeChannel() {
		channel.disconnect();
	}

	public Vector<swsLsEntry> ls() throws swsException {
		try {
			Vector<LsEntry> fileList = channelSftp.ls(dir);
			Vector<swsLsEntry> swsFileList = new Vector<swsLsEntry>(); 
			if (fileList != null) {
				for (int ii = 0; ii < fileList.size(); ii++) {
					swsFileList.add(new swsLsEntry(fileList.elementAt(ii)));
				}
			}
			return swsFileList;
			
		} catch (SftpException e) {
			throw new swsException(e);
		}
	}

	public void get(String sourceFile, String targetFile) throws swsException {
		try {
			channelSftp.get(dir+sourceFile, targetFile);
		} catch (SftpException e) {
			throw new swsException(e);
		}
	}

	public void rm(String file) throws swsException {
		try {
			channelSftp.rm(dir+file);
		} catch (SftpException e) {
			throw new swsException(e);
		}
	}


}
