package com.kb.sftp;

import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.SftpATTRS;

public class swsLsEntry extends com.jcraft.jsch.ChannelSftp.LsEntry {

	swsLsEntry(String filename, String longname, SftpATTRS attrs) {
		super(filename, longname, attrs);
	}

	swsLsEntry(LsEntry entry) {
		super(entry.getFilename(), entry.getLongname(), entry.getAttrs());
	}
	
}
