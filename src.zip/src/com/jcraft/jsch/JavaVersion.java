package com.jcraft.jsch;

final class JavaVersion {

  static int getVersion() {
    return 8;
  }
}
